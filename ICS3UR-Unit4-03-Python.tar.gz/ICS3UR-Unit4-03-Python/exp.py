#!/usr/bin/env python3

# Created by Gabriel A
# Created on Dec 2020
# This program calculates squares


def main():
    try:
        # input
        im = int(input("Enter a positive integer: "))
        print("")

    # process & output
        if im >= 0:
            for loop in range(im + 1):
                exp = loop ** 2
            print("{0}² is {1}.".format(im, exp))
        else:
            print("That is a negative integer.")

    except ValueError:
        print("")
        print("That is not an integer.")


if __name__ == "__main__":
    main()
